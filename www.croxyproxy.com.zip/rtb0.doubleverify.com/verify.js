

try{__tagObject_callback_383929148556({ImpressionID:"76c9ccf2e2c44e3285d18fd26408f09b", ServerPublicDns:"rtbc-eu3.doubleverify.com"});}catch(e){}
try{$dvbs.pubSub.publish('BeforeDecisionRender', "76c9ccf2e2c44e3285d18fd26408f09b");}catch(e){}
try{__verify_callback_383929148556({
ResultID:2,
Passback:"",
AdWidth:300,
AdHeight:250});}catch(e){}
try{$dvbs.pubSub.publish('AfterDecisionRender', "76c9ccf2e2c44e3285d18fd26408f09b");}catch(e){}
